<?php
/**
 * Sage includes
 *
 * The $sage_includes array determines the code library included in your theme.
 * Add or remove files to the array as needed. Supports child theme overrides.
 *
 * Please note that missing files will produce a fatal error.
 *
 * @link https://github.com/roots/sage/pull/1042
 */
$sage_includes = [
  'lib/assets.php',    // Scripts and stylesheets
  'lib/extras.php',    // Custom functions
  'lib/setup.php',     // Theme setup
  'lib/titles.php',    // Page titles
  'lib/wrapper.php',   // Theme wrapper class
  'lib/customizer.php' // Theme customizer
];

foreach ($sage_includes as $file) {
  if (!$filepath = locate_template($file)) {
    trigger_error(sprintf(__('Error locating %s for inclusion', 'sage'), $file), E_USER_ERROR);
  }

  require_once $filepath;
}
unset($file, $filepath);


// Clean Admin bar
function remove_admin_bar_links() {
	global $wp_admin_bar;
	$wp_admin_bar->remove_menu('wporg');            // Remove the Wordpress.org link
	$wp_admin_bar->remove_menu('updates');          // Remove the updates link
	$wp_admin_bar->remove_menu('customize');
}
add_action( 'wp_before_admin_bar_render', 'remove_admin_bar_links' );


/**
 * Extend Recent Posts Widget
 *
 * Adds different formatting to the default WordPress Recent Posts Widget
 */

Class My_Recent_Posts_Widget extends WP_Widget_Recent_Posts {
	
	function widget($args, $instance) {
		
		extract( $args );
		
		$all_post_link = '<a href="'. get_permalink( get_option( 'page_for_posts' )) .'" class="all-link"></a>';
		
		$title = apply_filters('widget_title', empty($instance['title']) ? __('Popular Posts') : $instance['title'], $instance, $this->id_base);
		
		if( empty( $instance['number'] ) || ! $number = absint( $instance['number'] ) )
			$number = 10;
		
		$r = new WP_Query( apply_filters( 'widget_posts_args', array( 'posts_per_page' => $number, 'no_found_rows' => true, 'post_status' => 'publish', 'ignore_sticky_posts' => true ) ) );
		if( $r->have_posts() ) :
			
			echo $before_widget;
			if( $title ) echo $before_title . $title . $all_post_link . $after_title; ?>
			<ul class="recent-posts-list">
				<?php while( $r->have_posts() ) : $r->the_post(); ?>
					<li>
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
							<span class="data"><?= get_the_date('m/d/Y'); ?></span>
							<span class="cat-name">
								<?php foreach((get_the_category()) as $category) {
									echo $category->cat_name . ' ';
								} ?>
							</span>
							<span class="title"><?php the_title(); ?></span>
						</a>
					</li>
				<?php endwhile; ?>
			</ul>
			
			<?php
			echo $after_widget;
			
			wp_reset_postdata();
		
		endif;
	}
}


function my_recent_widget_registration() {
	unregister_widget('WP_Widget_Recent_Posts');
	register_widget('My_Recent_Posts_Widget');
}
add_action('widgets_init', 'my_recent_widget_registration');


// Custom Excerpt link
function custom_excerpt_more($more) {
	global $post;
	$more_text = 'See more';
	return '… </br><a href="'. get_permalink($post->ID) . '" class="more-btn">' . $more_text . '</a>';
}
add_filter('excerpt_more', 'custom_excerpt_more');


function new_excerpt_more($more) {
	return '';
}
add_filter('excerpt_more', 'new_excerpt_more', 21 );

function the_excerpt_more_link( $excerpt ) {
	$post = get_post();
	$more_text = 'See more';
	$excerpt .= '<a href="'. get_permalink($post->ID) . '" class="more-btn">' . $more_text . '</a>';
	
	return $excerpt;
}
add_filter( 'the_excerpt', 'the_excerpt_more_link', 21 );


// [subtitle text="value"]
function subtitle_func( $atts ) {
	$a = shortcode_atts( array(
		'text' => '',
	), $atts );
	
	return "<p class=\"subtitle-section\"> " . $a['text'] ."</p>	";
}
add_shortcode( 'subtitle', 'subtitle_func' );


// [cta url="value"]
function cta_func( $atts, $content = null) {
	$a = shortcode_atts( array(
		'url' => '',
	), $atts );
	
	$content = do_shortcode($content);
	
	return "<a class=\"cta\" href='" . $a['url'] . "'> " . $content ."</a>	";
}
add_shortcode( 'cta', 'cta_func' );


// Add Google Maps API Key
function my_acf_init() {
	acf_update_setting('google_api_key', 'AIzaSyAiYaF2JRRZVIpLTZz17-rh2We-lPRzNVw');
}
add_action('acf/init', 'my_acf_init');

function my_theme_add_scripts() {
	wp_enqueue_script( 'google-map', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyAiYaF2JRRZVIpLTZz17-rh2We-lPRzNVw', array(), '3', true );
}

add_action( 'wp_enqueue_scripts', 'my_theme_add_scripts' );

function my_acf_google_map_api( $api ) {
	
	$api['key'] = 'AIzaSyAiYaF2JRRZVIpLTZz17-rh2We-lPRzNVw';
	
	return $api;
}
add_filter('acf/fields/google_map/api', 'my_acf_google_map_api');