<?php get_template_part('templates/page', 'header'); ?>

<div class="single-post-page">
  <div class="section latest_news search mb-5-rem">
    <div class="container">
      <?php if (!have_posts()) : ?>
        <div class="alert alert-warning">
          <?php _e('Sorry, no results were found.', 'sage'); ?>
        </div>
      <?php endif; ?>
  
      &nbsp;
      <?php get_search_form(); ?>
      &nbsp;
  
      <ul class="latest-news-list">
        <?php while (have_posts()) : the_post(); ?>
          <?php get_template_part('templates/content', 'search'); ?>
        <?php endwhile; ?>
      </ul>
      
      <?php
			$args = array(
				'prev_text'          => __( ' ' ),
				'next_text'          => __( ' ' )
			);
      
      the_posts_navigation($args);
      ?>
    </div>
  </div>
</div>