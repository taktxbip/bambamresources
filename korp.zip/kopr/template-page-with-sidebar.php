<?php
/**
 * Template Name: Page With Sidebar
 */
?>

<?php while (have_posts()) : the_post(); ?>
	<?php get_template_part('templates/page', 'header'); ?>
	
	<div id="section-1" class="simple-page">
		<div class="container">
			<div class="row">
				<?php
				$home_page_id = get_option('page_on_front');
				$sidebar = get_field('show_stock_sidebar', $page_id);
				$subscribe_form = get_field('show_subscribe_form', $page_id);
				$news_alerts_form = get_field('news_alerts_form', $home_page_id);
				?>
			
					<div class="main simple-page-content">
						<?php the_content(); ?>
						<?php wp_link_pages(['before' => '<nav class="page-nav"><p>' . __('Pages:', 'sage'), 'after' => '</p></nav>']); ?>
						
						<?php if($subscribe_form) : ?>
							<div class="subscribe_form">
								<h2 class="form-title">Subscribe to our newsletter to get the latest updates </h2>
								<div class="sign-up-form">
									<?php echo gravity_form($news_alerts_form, FALSE, FALSE, FALSE, '', TRUE); ?>
								</div>
							</div>
						<?php endif; ?>
					</div>
					
					<div class="sidebar">
						<div class="stock-sidebar">
							<h2>Stock Price</h2>
							
							<?php while( have_rows('stocks', $home_page_id) ): the_row(); ?>
								<div class="stockquote">
									<?php $hide_iframe = get_sub_field('hide_iframe', $home_page_id); ?>
									<span>
                  <?php echo get_sub_field('stock_exchange') . ': ' . get_sub_field('symbol'); ?>
										<?php if (!$hide_iframe) : ?>
											<span class="currency">(<?= get_sub_field('stock_currency'); ?>)</span>
										<?php endif;?>
                </span>
									<?php if (!$hide_iframe) : ?>
										<div class="stock-frame">
											<iframe frameBorder='0' scrolling='no' width='130' height='30' src='https://api.stockdio.com/visualization/financial/charts/v1/SingleQuote?app-key=83A670B02A0D4D7495C074D0C9E5BB44&stockExchange=<?= get_sub_field('stockdio_exchange'); ?>&symbol=<?= get_sub_field('stockdio_symbol'); ?>&includeSymbol=false&includeCompany=false&includePercentChange=false&includeTrend=false&showLogo=No&logoAlignment=Center&motif=Healthy&palette=Lilacs-in-Mist&showBorder=false&width=130px&height=30px&font=Open%20Sans&fontSize=14&googleFont=true&borderColor=ffffff&backgroundColor=ffffff&labelsColor=000000&positiveColor=51b543&negativeColor=d0021b'></iframe>
										</div>
									<?php endif;?>
								</div>
							<?php endwhile; ?>
							<p class="description">Pricing delayed 20 minutes</p>
						</div>
						
						<div class="quick-links">
							<?php
							$presentation = get_field('investor_presentation', $home_page_id);
							
							if( $presentation['display_investor_presentation'] ): ?>
								<a href="<?php echo $presentation['investor_presentation']['url']; ?>" download class="file">
                <span class="icon">
                  <img src="<?php echo get_template_directory_uri() . '/dist/images/presentation_icon.svg' ;?>" alt="">
                </span>
									<span class="labels">
                  <span class="title">Investor Presentation</span></br>
										<span class="subtitle">Download</span>
                </span>
								</a>
							<?php endif; ?>
							<?php
							$f_sheet = get_field('fact_sheet', $home_page_id);
							
							if( $f_sheet['display_fact_sheet'] ): ?>
								<a href="<?php echo $f_sheet['fact_sheet']['url']; ?>" download class="file">
                <span class="icon">
                  <img src="<?php echo get_template_directory_uri() . '/dist/images/pdf_icon.svg' ;?>" alt="">
                </span>
									<span class="labels">
                  <span class="title">Fact Sheet</span></br>
										<span class="subtitle">Download</span>
                </span>
								</a>
							<?php endif; ?>
						</div>
					</div>
				
			</div>
		</div>
	</div>
<?php endwhile; ?>
