<?php get_template_part('templates/page', 'header'); ?>

<div class="single-post-page">
  <div class="section latest_news mb-5-rem">
    <div class="container">
      <div class="alert alert-warning">
        <?php _e('Sorry, but the page you were trying to view does not exist.', 'sage'); ?>
      </div>
      
      <?php get_search_form(); ?>
      &nbsp;
    </div>
  </div>
</div>
