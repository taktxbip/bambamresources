<div class="row">
		<?php
		$home_page_id = get_option('page_on_front');
		$news_alerts_form = get_field('news_alerts_form', $home_page_id);
		?>
	
	<div class="col-md-8 col-lg-6">
		<h2 class="form-title"><?= get_sub_field('title'); ?></h2>
		<div class="sign-up-form">
			<?php echo gravity_form($news_alerts_form, FALSE, FALSE, FALSE, '', TRUE); ?>
		</div>
	</div>
</div>