<div class="row">
	<div class="col-12">
		<?php $home_page_id = get_option('page_on_front'); ?>
		
		<div class="quick-links">
			<?php
			$presentation = get_field('investor_presentation', $home_page_id);
			
			if( $presentation['display_investor_presentation'] ): ?>
				<a href="<?= $presentation['investor_presentation']['url']; ?>" download class="file">
					<span class="icon">
						<img class="white-icon" src="<?= get_template_directory_uri() . '/dist/images/presentation_icon-white.svg' ;?>" alt="">
            <img class="dark-icon" src="<?= get_template_directory_uri() . '/dist/images/presentation_icon-black.svg' ;?>" alt="">
					</span>
					<span class="labels">
						<span class="title">Investor Presentation</span></br>
						<span class="subtitle">Download</span>
					</span>
				</a>
			<?php endif; ?>
			<?php
			$f_sheet = get_field('fact_sheet', $home_page_id);
			
			if( $f_sheet['display_fact_sheet'] ): ?>
				<a href="<?= $f_sheet['fact_sheet']['url']; ?>" download class="file">
					<span class="icon">
						<img class="white-icon" src="<?= get_template_directory_uri() . '/dist/images/pdf_icon-white.svg' ;?>" alt="">
            <img class="dark-icon" src="<?= get_template_directory_uri() . '/dist/images/pdf_icon-black.svg' ;?>" alt="">
					</span>
					<span class="labels">
						<span class="title">Fact Sheet</span></br>
						<span class="subtitle">Download</span>
					</span>
				</a>
			<?php endif; ?>
		</div>
	</div>
</div>