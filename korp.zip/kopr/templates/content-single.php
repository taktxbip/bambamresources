<?php //get_template_part('templates/page', 'header'); ?>

<div class="single-post-page">
  <div class="section latest_news">
    <div class="container">
      <div class="row">
        <div class="main">
          <div class="big-news">
						
						<?php while (have_posts()) : the_post(); ?>
							<?php if (get_the_post_thumbnail_url()) : ;?>
                <img class="post-banner" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
							<?php endif; ?>

              <span class="news-item">
                <span class="date"><?php echo get_the_date('m/d/Y'); ?></span>
                <span class="news-category">
                  <?php foreach((get_the_category()) as $category) {
										echo $category->cat_name . ' ';
									} ?>
                </span>
              </span>

              <h2 class="big-news-title"><?php the_title(); ?></h2>
              <div class="the-content"><?php the_content(); ?></div>
						
						<?php endwhile; ?>
          </div>

          <nav class="navigation posts-navigation single-post-nav">
            <div class="nav-links">
              <div class="nav-previous">
								<?php previous_post_link(); ?>
              </div>
              <div class="nav-next">
								<?php next_post_link(); ?>
              </div>
            </div>
          </nav>
        </div>

        <div class="sidebar">
					<?php get_template_part('templates/sidebar');?>
        </div>
      </div>
    </div>
  </div>
</div>
