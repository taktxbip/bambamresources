<?php
use Roots\Sage\Titles;
$page_id             = get_queried_object_id();
if (is_category()) {
	$page_id           = 'category_'.$page_id;
}
if (is_tag()) {
	$page_id           = 'post_tag_'.$page_id;
}

$type                = get_field('header_type', $page_id);
$title               = get_field('header_title', $page_id);
$video_def_bg_img    = get_field('video_default_background_image', $page_id);

$image               = get_the_post_thumbnail_url($page_id);

?>
<?php
switch ($type) {
	
	// Video header
	case 'video': ?>
    <section class="page-header with-image video-header">
      <div class="bg-video" style="background: url(<?= $video_def_bg_img['url']; ?>) center center no-repeat;">
        <video muted autoplay loop poster="<?= $video_def_bg_img['url']; ?>">
          <source src="<?= get_field('video_mp4_file')['url']; ?>" type='video/mp4; codecs="avc1.42E01E, mp4a.40.2"'>
          <source src="<?= get_field('video_webm_file')['url']; ?>" type='video/webm; codecs="vp8, vorbis"' />
        </video>
      </div>
      
      <div class="container">
        <div class="centrall-block">
          <a href="<?= get_field('video_popup_url'); ?>" class="play-button popup-video-<?= get_field('video_popup_type'); ?>">
            <img src="<?php echo get_template_directory_uri() . '/dist/images/icon-play.svg' ;?>" alt="">
          </a>
          
          <h1><?= get_field('header_title', $page_id); ?></h1>
					<?php if(get_field('header_subtitle', $page_id)) : ?>
            <p class="description" ><?= get_field('header_subtitle', $page_id); ?></p>
					<?php endif; ?>
        </div>
      </div>
      <a href="#section-1" class="scroll-down">
        <img src="<?php echo get_template_directory_uri() . '/dist/images/icon-arrow-down.svg' ;?>" alt="">
        <span>Scroll Down</span>
      </a>
    </section>
		<?php
		break;
	
	// Custom header
	case 'custom': ?>
		<?php if ( $image ) : ?>
      <section class="page-header with-image" style="background: url(<?= $image; ?>) center center no-repeat;">
        <div class="container">
          <div class="centrall-block">
            <h1><?= get_field('header_title', $page_id); ?></h1>
						<?php if(get_field('header_subtitle', $page_id)) : ?>
              <p class="description" ><?= get_field('header_subtitle', $page_id); ?></p>
						<?php endif; ?>&nbsp;
          </div>
        </div>
        <a href="#section-1" class="scroll-down">
          <img src="<?php echo get_template_directory_uri() . '/dist/images/icon-arrow-down.svg' ;?>" alt="">
          <span>Scroll Down</span>
        </a>
      </section>
		<?php else : ?>
      <section class="page-header without-image">
        <div class="container">
          <div class="centrall-block">
            <h1><?= get_field('header_title', $page_id); ?></h1>
						<?php if(get_field('header_subtitle', $page_id)) : ?>
              <p class="description" ><?= get_field('header_subtitle', $page_id); ?></p>
						<?php endif; ?>
          </div>
        </div>
      </section>
		<?php endif; ?>
		<?php
		break;
	
	// Default header
	default: ?>
		<?php if ( $image ) : ?>
      <section class="page-header with-image" style="background: url(<?= $image; ?>) center center no-repeat;">
        <div class="container">
          <div class="centrall-block">
            <h1><?= Titles\title(); ?></h1>
          </div>
        </div>
        <a href="#section-1" class="scroll-down">
          <img src="<?php echo get_template_directory_uri() . '/dist/images/icon-arrow-down.svg' ;?>" alt="">
          <span>Scroll Down</span>
        </a>
      </section>
		<?php else : ?>
      <section class="page-header without-image">
        <div class="container">
          <div class="centrall-block">
            <h1><?= Titles\title(); ?></h1>
          </div>
        </div>
      </section>
		<?php endif; ?>
		
		<?php
		break;
} ?>
