<div class="map-container">
	<div class="contact-map">
		<?php $location = get_sub_field('location'); ?>
  
		<?php if( have_rows('locations') ): ?>
      <div class="acf-map">
				<?php while ( have_rows('locations') ) : the_row();
					$location = get_sub_field('location');
					?>
          <div class="marker" data-lat="<?= $location['lat']; ?>" data-lng="<?= $location['lng']; ?>"
               data-show="<?= get_sub_field('show_info_window') ? 'true' : '' ?>"
               data-info-position="<?= get_sub_field('infowindow_position') ? 'true' : '' ?>"
          >
            <h5 class="pin-title"><?= get_sub_field('title'); ?></h5>
            <?php if (get_sub_field('pin_url')) : ?>
              <a href="<?= get_sub_field('pin_url'); ?>" target="_blank" class="more-btn">See more</a>
						<?php endif; ?>
          </div>
				<?php endwhile; ?>
      </div>
		<?php endif; ?>
    
    <span class="hidden-pin-url"><?= get_template_directory_uri() . '/dist/images/pin.svg' ;?></span>
	</div>
  
  <div class="mobile-img-map">
    <img src="<?= get_sub_field('mobile_img_map'); ?>" alt="map">
  </div>
</div>