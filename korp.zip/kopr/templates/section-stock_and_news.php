<?php $home_page_id = get_option('page_on_front'); ?>

<div class="row">
	<div class="col-md-6">
		<div class="stock-block">
			<h2><?= get_sub_field('stock_title'); ?></h2>
			
			<?php while( have_rows('stocks', $home_page_id) ): the_row(); ?>
                <?php $hide_iframe = get_sub_field('hide_iframe', $home_page_id); ?>
                <?php if (!$hide_iframe) : ?>
				<div class="stockquote">

     
					<span>
						<?php echo get_sub_field('stock_exchange') . ': ' . get_sub_field('symbol'); ?>

              <span class="currency">(<?= get_sub_field('stock_currency'); ?>)</span>

					</span>
          <?php if (!$hide_iframe) : ?>
            <div class="stock-frame">
              <iframe frameBorder='0' scrolling='no' width='130' height='30' src='https://api.stockdio.com/visualization/financial/charts/v1/SingleQuote?app-key=83A670B02A0D4D7495C074D0C9E5BB44&stockExchange=<?= get_sub_field('stockdio_exchange'); ?>&symbol=<?= get_sub_field('stockdio_symbol'); ?>&includeSymbol=false&includeCompany=false&includePercentChange=false&includeTrend=false&showLogo=No&logoAlignment=Center&motif=Healthy&palette=Lilacs-in-Mist&showBorder=false&width=130px&height=30px&font=Open%20Sans&fontSize=14&googleFont=true&borderColor=364e90&backgroundColor=364e90&labelsColor=ffffff&positiveColor=51b543&negativeColor=d0021b'></iframe>
            </div>
          <?php endif;?>
				</div>
                <?php endif;?>
			<?php endwhile; ?>
			<p class="description">Pricing delayed 20 minutes</p>
		</div>
	</div>
	
	<div class="col-md-6">
		<div class="news-block">
			<div class="title-block">
				<h2><?= get_sub_field('news_title'); ?></h2>
				<a href="<?= get_permalink( get_option( 'page_for_posts' ) ); ?>" class="more-btn">See more</a>
			</div>
			
			<ul class="latest-news-list">
				<?php
				global $post;
				$args = array(
					'posts_per_page' => 3,
					'post_type' => 'post',
				);
				$myposts = get_posts( $args );
				foreach( $myposts as $post ) {
					setup_postdata($post);
					?>
					<li>
						<a href="<?php the_permalink(); ?>" class="news-item ">
							<span class="date"><?= get_the_date('m/d/Y'); ?></span>
							<span class="news-category">
								<?php
									foreach((get_the_category()) as $category) {
										echo $category->cat_name . ' ';
									}
								?>
							</span>
							<span class="news-title"><?php the_title(); ?></span>
						</a>
					</li>
					<?php
				}
				wp_reset_postdata();
				?>
			</ul>
		</div>
	</div>
</div>