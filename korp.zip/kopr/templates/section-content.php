<div class="row">
	<div class="simple-content wrapping-<?= get_sub_field('wrapping'); ?>">
		<?php echo do_shortcode( get_sub_field('content')); ?>
	</div>
</div>