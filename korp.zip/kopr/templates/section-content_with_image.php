<div class="row">
	<div class="simple-content wrapping-<?= get_sub_field('wrapping'); ?>">
		<div class="img-wrap">
			<img src="<?= get_sub_field('image')['url']; ?>" alt="<?= get_sub_field('image')['alt']; ?>">
		</div>
		
		<?php echo do_shortcode( get_sub_field('content')); ?>
	</div>
</div>