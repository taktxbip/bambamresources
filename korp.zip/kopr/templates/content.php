<a href="<?php the_permalink(); ?>" class="news-item ">
  <span class="date"><?php echo get_the_date('m/d/Y'); ?></span>
  <span class="news-category">
    <?php
		foreach((get_the_category()) as $category) {
			echo $category->cat_name . ' ';
		}
		?>
  </span>
  <span class="news-title"><?php the_title(); ?></span>
</a>