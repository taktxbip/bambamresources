<?php
$home_page_id = get_option('page_on_front');
$page_id = get_queried_object_id();
$image   = get_the_post_thumbnail($page_id);

if (is_single() || is_category() || is_tag() || is_archive()) {
	$image = '';
}
$type    = get_field('header_type', $page_id);

$show_stock = get_field('display_stocks', $home_page_id);
?>
<header class="banner <?= $image ? '' : 'white-header'; ?>">
	<?php if($show_stock) : ?>
    <div class="stock-wrap">
      <div class="container">
        <div class="stock">
          <div class="stock-price-block">
            <?php while( have_rows('stocks', $home_page_id) ): the_row(); ?>
              
              <?php $hide_iframe = get_sub_field('hide_iframe', $home_page_id); ?>
              <div class="stockquote <?= $hide_iframe ? ' only-symbol' : ''; ?> "><?php echo get_sub_field('stock_exchange') . ': ' . get_sub_field('symbol'); ?>
								<?php if (!$hide_iframe) : ?>
                  <span class="currency">(<?= get_sub_field('stock_currency'); ?>)</span>
                  <div class="stock-frame">
                    <iframe frameBorder='0' scrolling='no' width='125' height='28' src='https://api.stockdio.com/visualization/financial/charts/v1/SingleQuote?app-key=83A670B02A0D4D7495C074D0C9E5BB44&stockExchange=<?= get_sub_field('stockdio_exchange'); ?>&symbol=<?= get_sub_field('stockdio_symbol'); ?>&includeSymbol=false&includeCompany=false&includePercentChange=false&includeTrend=false&showLogo=No&logoAlignment=Center&motif=Healthy&palette=Lilacs-in-Mist&showBorder=false&width=125px&height=28px&font=Open%20Sans&fontSize=16&googleFont=true&borderColor=ffffff&backgroundColor=ffffff&labelsColor=000000&positiveColor=51b543&negativeColor=d0021b'></iframe>
                  </div>
								<?php endif;?>
              
              </div>
            <?php endwhile; ?>
          </div>
        </div>
      </div>
    </div>
	<?php endif;?>

  <div class="container">
    <div class="header">
      <a class="brand" href="<?= esc_url(home_url('/')); ?>">
        <img src="<?= get_template_directory_uri() . '/dist/images/black-logo-new.svg' ;?>" alt="" class="dark-logo">
        <img src="<?= get_template_directory_uri() . '/dist/images/white-logo-new.svg' ;?>" alt="" class="white-logo">
      </a>

      <div class="btns-wrap">
        <a href="#" id="show-form" data-toggle="modal" data-target="#signUpModal" class="subscribe-btn">Subscribe</a>
        
        <div class="navigation navbar-light">
          <button type="button" class="navbar-toggler hamburger hamburger--squeeze" data-toggle="collapse" data-target="#navbarSupportedContent">
            <span class="hamburger-top-line"></span>
            <span class="hamburger-mid-line"></span>
            <span class="hamburger-bot-line"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="content-menu">
              <div class="primary_navigation">
                <?php
                if (has_nav_menu('primary_navigation')) :
                  wp_nav_menu(['theme_location' => 'primary_navigation', 'menu_class' => 'nav ']);
                endif;
                ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
	<?php
	if (have_rows('sections', $page_id)) :
		while (have_rows('sections', $page_id)) : the_row();
			$section = get_row_layout();
			if ($section == 'project-subnavigation') { ?>
        <div class="subnav project-subnav">
          <div class="container">
            <div class="links">
							<?php $nav_tabs = get_sub_field('subnavigation', $page_id);
							
							foreach( $nav_tabs as $tab ): ?>
                <a href="<?= $tab['link']; ?>" class="sub-nav-link"><?= $tab['title']; ?></a>
							<?php endforeach; ?>
            </div>

            <span class="before"><i class="fa fa-angle-left" aria-hidden="true"></i></span>
            <span class="after"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
          </div>
        </div>
			<?php }
		endwhile; ?>
	<?php endif; ?>
 
	<?php
	if (have_rows('sections', $page_id)) :
		while (have_rows('sections', $page_id)) : the_row();
			$section = get_row_layout();
			if ($section == 'subnavigation') { ?>
        <div class="subnav subnav-simple">
          <div class="container">
            <div class="links">
							<?php $nav_tabs = get_sub_field('subnavigation', $page_id);
							
							foreach( $nav_tabs as $tab ): ?>
                <a href="<?= $tab['link']; ?>" class="sub-nav-link"><?= $tab['title']; ?></a>
							<?php endforeach; ?>
            </div>

            <span class="before"><i class="fa fa-angle-left" aria-hidden="true"></i></span>
            <span class="after"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
          </div>
        </div>
			<?php }
		endwhile; ?>
	<?php endif; ?>
</header>

<!-- Modal -->
<div class="modal fade" id="signUpModal" tabindex="-1" role="dialog" aria-labelledby="signUpModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" class="close-top-line"></span>
          <span aria-hidden="true" class="close-bottom-line"></span>
        </button>
      </div>
      <div class="modal-body">
				<?php
				$news_alerts_title = get_field('news_alerts_title', $home_page_id);
				$news_alerts_subtitle = get_field('news_alerts_description', $home_page_id);
				$news_alerts_form = get_field('news_alerts_form', $home_page_id);
				?>

        <h2 class="modal-title"><?= $news_alerts_title; ?></h2>
				<?php if($news_alerts_subtitle) : ?>
          <p class="modal-description"><?= $news_alerts_subtitle; ?></p>
				<?php endif; ?>
        <div class="sign-up-form">
					<?php echo gravity_form($news_alerts_form, FALSE, FALSE, FALSE, '', TRUE); ?>
        </div>
      </div>
      <div class="modal-footer"></div>
    </div>
  </div>
</div>