<li>
  <a href="<?php the_permalink(); ?>" class="news-item search-news">
    <span class="news-title"><?php the_title(); ?></span>
  </a>
</li>
