<div id="section-1" class="simple-page default-template">
  <div class="container">
    <div class="row">
      <div class="col-12 simple-page-content">
        <?php the_content(); ?>
        <?php wp_link_pages(['before' => '<nav class="page-nav"><p>' . __('Pages:', 'sage'), 'after' => '</p></nav>']); ?>
      </div>
    </div>
  </div>
</div>
