<?php
if (have_rows('sections', $page_id)) :
	$section_number = 1;
	while (have_rows('sections', $page_id)) : the_row();
		// Background Image
		$section = get_row_layout();
		$classes = '';
		// Get Content ACF Variables
		if ($section == 'content') {
			$section_padding = get_sub_field('padding');
			$classes .= ' '.$section_padding;
			if (get_sub_field('centered')) : $classes .= ' centered ' ; endif ;
		}
		?>
		<div id="section-<?= $section_number ?>"
				 class=" section builder-section
        <?= $section; ?>
        <?php the_sub_field('section_type')?>
        <?= get_sub_field('background') ? 'bg-'.get_sub_field('background') : '' ?>
        <?= $classes ?>
        padding-<?= get_sub_field('padding'); ?>
        <?= get_sub_field('section_color'); ?>"
		>
			<div class="container <?= (get_sub_field('full-width-container' ) ? 'full-width-container' : '') ?>">
				<?php
				switch ($section) {
					
					// Content With Img
					case 'content_with_featured_image':
						get_template_part('templates/section-content_with_image');
						break;
      
					// Stock Information & Latest news
					case 'stock_information_latest_news':
						get_template_part('templates/section-stock_and_news');
						break;
					
					// Map
					case 'map':
						get_template_part('templates/section-map');
						break;
					
					// Quick Links
					case 'quick_links':
						get_template_part('templates/section-quick_links');
						break;
					
					// Gallery
					case 'gallery':
						get_template_part('templates/section-gallery');
						break;
      
					// News Alert Form
					case 'news_alert_form':
						get_template_part('templates/section-news_alert_form');
						break;
					
					// Contact Form
					case 'contact_form':
						get_template_part('templates/section-form');
						break;
					
					// Default: Content
					default:
						get_template_part('templates/section-content');
						break;
				} ?>
			</div>
		</div>
		<?php
		$section_number++;
	endwhile;
endif;
?>