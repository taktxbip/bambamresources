<div class="form-container">
  <?php $title = get_sub_field( 'form_title', $page_id); ?>
  <?php if($title) : ?>
    <h2 class="section-title"><?= $title; ?></h2>
	<?php endif; ?>
  
  <?php
    $form = get_sub_field( 'form', $page_id);
    echo do_shortcode( '[gravityform id=' . $form .' ajax=true title=false description=false]' );
  ?>
</div>