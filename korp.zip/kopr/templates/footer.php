<?php
  $home_page_id = get_option('page_on_front');
  $front_page_id = get_option('page_on_front');
?>

<footer class="section footer">
  <div class="container relative">
    <div class="scroll-top">
      <a href="#" class="scroll-top-btn">
        <span class="label">Go up</span>
      </a>
    </div>
  </div>
  
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="col-lg-7 menus">
					<?php if (has_nav_menu('footer_navigation')) :
						wp_nav_menu(['theme_location' => 'footer_navigation', 'menu_class' => 'footer_menu ']);
					endif; ?>
          
          <div class="group">
            <?php
              $group_title  = get_field('group_title', $front_page_id);
              $links_block   = get_field('investors_block', $front_page_id);
            ?>
            
					  <h3><?= $group_title; ?></h3>
	          <ul>
              <?php foreach( $links_block as $link ): ?>
                <li>
                  <a href="<?= $link['link_url']; ?>" class="link">
                    <?= $link['link_title']; ?>
                  </a>
                </li>
              <?php endforeach; ?>

              <div class="quick-links">
								<?php
								$presentation = get_field('investor_presentation', $home_page_id);
	
								if( $presentation['display_investor_presentation'] ): ?>
                  <a href="<?php echo $presentation['investor_presentation']['url']; ?>" download class="file">
                    <span class="title">Presentation</span>
                    <img src="<?php echo get_template_directory_uri() . '/dist/images/icon-download.svg' ;?>" alt="">
                  </a>
								<?php endif; ?>
                <?php
                $f_sheet = get_field('fact_sheet', $home_page_id);
        
                if( $f_sheet['display_fact_sheet'] ): ?>
                  <li>
                    <a href="<?php echo $f_sheet['fact_sheet']['url']; ?>" download class="file">
                      <span class="title">Fact Sheet</span>
                      <img src="<?php echo get_template_directory_uri() . '/dist/images/icon-download.svg' ;?>" alt="">
                    </a>
                  </li>
                <?php endif; ?>
              </div>
            </ul>
          </div>
        </div>

        <div class="col-lg-5">
          <div class="footer-soc-links">
						<?php
              $facebook_url  = get_field('social_media_facebook', $front_page_id);
              $twitter_url   = get_field('social_media_twitter', $front_page_id);
              $linkedin_url  = get_field('social_media_linkedin', $front_page_id);
						?>
      
						<?php if($facebook_url || $twitter_url || $linkedin_url) : ?>
              <h3 class="">Connect With Us</h3>
              
              <ul class="social-list">
                <?php if($facebook_url) : ?>
                  <li class="social-item">
                    <a href="<?= $facebook_url; ?>">
                      <i class="fa fa-facebook" aria-hidden="true"></i>
                      Facebook
                    </a>
                  </li>
                <?php endif; ?>
                <?php if($twitter_url) : ?>
                  <li class="social-item">
                    <a href="<?= $twitter_url; ?>">
                      <i class="fa fa-twitter" aria-hidden="true"></i>
                      Twitter
                    </a>
                  </li>
                <?php endif; ?>
                <?php if($linkedin_url) : ?>
                  <li class="social-item">
                    <a href="<?= $linkedin_url; ?>">
                      <i class="fa fa-linkedin" aria-hidden="true"></i>
                      LinkedIn
                    </a>
                  </li>
                <?php endif; ?>
              </ul>
						<?php endif; ?>
          </div>
          
          <div class="subscribe-form">
            <h3>Subscribe to our newsletter</h3>
            <div class="form">
							<?php echo gravity_form(get_field('news_alerts_form', $home_page_id), FALSE, FALSE, FALSE, '', TRUE); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="container">
    <div class="footer-bottom">
      <p>&copy;<?php echo date("Y"); ?> <?php echo get_bloginfo('name') ?></p>
      <?php if (has_nav_menu('colophon_navigation')) :
        wp_nav_menu(['theme_location' => 'colophon_navigation', 'menu_class' => 'nav ']);
      endif; ?>
    </div>
  </div>
</footer>