<?php get_template_part('templates/page', 'header'); ?>

<?php if (!have_posts()) : ?>
  <div class="section news">
    <div class="container">
      <div class="alert alert-warning">
				<?php _e('Sorry, no results were found.', 'sage'); ?>
      </div>
			<?php get_search_form(); ?>
    </div>
  </div>
<?php endif; ?>

<div class="section news">
  <div class="container">
    <div class="row">
      <div class="main">

        <div class="latest_news-content padding-default">
          <ul class="latest-news-list">
						<?php if (have_posts()) : ?>
							<?php while (have_posts()) : the_post(); ?>

                <div class="big-news">
									<?php if (get_the_post_thumbnail_url()) : ;?>
                    <a href="<?php the_permalink(); ?>">
                      <img class="post-banner" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                    </a>
									<?php endif; ?>
                  <span class="news-item">
                    <span class="date"><?= get_the_date('m/d/Y'); ?></span>
                    <span class="news-category">
                      <?php foreach((get_the_category()) as $category) {
												echo $category->cat_name . ' ';
											} ?>
                    </span>
                  </span>

                  <h2 class="big-news-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                  <div class="excerpt"><?php the_excerpt(); ?></div>
                </div>
							<?php endwhile; ?>
						<?php endif; ?>
          </ul>
        </div>
				<?php
				$args = array(
					'prev_text'          => __( ' ' ),
					'next_text'          => __( ' ' )
				);
				
				the_posts_navigation($args);
				?>
      </div>

      <div class="sidebar">
				<?php get_template_part('templates/sidebar');?>
      </div>
    </div>
  </div>
</div>